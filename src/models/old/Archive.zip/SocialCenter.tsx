export interface SocialCenter {
  cs_code?: string;
  name?: string;
  platform?: number;
}
