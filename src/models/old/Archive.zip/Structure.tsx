export interface OldStructure {
  id?: number;
  structureShortName?: string;
  structureName?: string;
  manager?: string;
  statusStructure?: string;
  bp?: string;
  fax?: string;
  email?: string;
  phone?: string;
  address?: string;
  platform?: number;
  cs_code?: string;
  creator?: string;
  date_created?: string;
  voice?: string;
  date_voice?: string;
}
